# CineVerse

Projeto demonstrativo de catálogo de filmes e séries para GitHub Pages, feito com HTML, CSS e JavaScript puro.

## Arquivos
- `index.html`: página inicial.
- `filmes.html`: catálogo de filmes com pesquisa, filtro e ordenação.
- `series.html`: catálogo de séries com pesquisa, filtro e ordenação.
- `detalhes.html`: página dinâmica de detalhes. Exemplo: `detalhes.html?id=eco-das-estrelas`.
- `minha-lista.html`: favoritos salvos no navegador via `localStorage`.
- `style.css`: estilos e layout responsivo.
- `script.js`: dados fictícios, navegação e interações.
- `img/`: pôsteres SVG locais feitos para este projeto.

## Publicar no GitHub Pages
1. Crie um repositório no GitHub.
2. Envie todos os arquivos e a pasta `img` para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois salve.
6. Aguarde o GitHub gerar o endereço do site.

Os caminhos dos arquivos são relativos, então o projeto também funciona em repositórios publicados sob `usuario.github.io/nome-do-repositorio/`.

## Observações
- O catálogo usa títulos e artes fictícios.
- Esta versão não reproduz filmes nem inclui links de vídeo.
- A lista de favoritos é salva somente no navegador atual. Não há login ou banco de dados.
- A fonte do Google Fonts é opcional; se não carregar, o site usa fontes alternativas.
