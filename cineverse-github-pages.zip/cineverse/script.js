/* CineVerse: catálogo fictício para GitHub Pages. Não há links de reprodução inventados. */
(() => {
  "use strict";

  const titles = [
    {id:"eco-das-estrelas",title:"O Eco das Estrelas",type:"movie",year:2026,genre:"Ficção científica",duration:"2h 08min",rating:"L",poster:"img/eco-das-estrelas.svg",featured:true,description:"Quando um sinal desconhecido atravessa a galáxia, uma equipe de exploradores parte para descobrir sua origem. A missão muda quando percebem que a mensagem parece responder às perguntas que ainda não fizeram.",tag:"DESTAQUE"},
    {id:"cidade-de-neon",title:"Cidade de Neon",type:"movie",year:2025,genre:"Ação",duration:"1h 54min",rating:"14",poster:"img/cidade-de-neon.svg",featured:true,description:"Em uma metrópole que nunca dorme, uma entregadora encontra um arquivo capaz de derrubar os poderosos que controlam cada rua iluminada."},
    {id:"o-ultimo-farol",title:"O Último Farol",type:"movie",year:2024,genre:"Mistério",duration:"1h 47min",rating:"12",poster:"img/o-ultimo-farol.svg",featured:true,description:"Uma restauradora chega a uma ilha isolada para cuidar de um farol antigo. Todas as noites, a luz aponta para um lugar diferente, e os moradores juram que isso nunca aconteceu antes."},
    {id:"jardim-de-cinzas",title:"Jardim de Cinzas",type:"movie",year:2025,genre:"Drama",duration:"2h 01min",rating:"12",poster:"img/jardim-de-cinzas.svg",featured:true,description:"Após voltar à cidade onde cresceu, uma fotógrafa encontra cartas que revelam a história esquecida de três gerações de sua família."},
    {id:"orbita-zero",title:"Órbita Zero",type:"movie",year:2023,genre:"Ficção científica",duration:"1h 59min",rating:"10",poster:"img/orbita-zero.svg",featured:true,description:"A tripulação de uma estação orbital perde contato com a Terra e precisa descobrir por que os registros da estação mostram acontecimentos que ainda não ocorreram."},
    {id:"mapa-do-impossivel",title:"Mapa do Impossível",type:"movie",year:2022,genre:"Aventura",duration:"1h 51min",rating:"L",poster:"img/mapa-do-impossivel.svg",featured:false,description:"Dois irmãos encontram um mapa que redesenha seus caminhos a cada amanhecer. Para encontrar a origem do objeto, terão de aprender a confiar um no outro."},
    {id:"risos-de-aluguel",title:"Risos de Aluguel",type:"movie",year:2024,genre:"Comédia",duration:"1h 38min",rating:"12",poster:"img/risos-de-aluguel.svg",featured:false,description:"Uma pequena agência oferece amigos por hora para eventos sociais. O plano funciona até que todos os clientes marcam seus compromissos para o mesmo dia."},
    {id:"bosque-escuro",title:"O Bosque Escuro",type:"movie",year:2025,genre:"Terror",duration:"1h 42min",rating:"16",poster:"img/bosque-escuro.svg",featured:false,description:"Um grupo de amigos passa uma noite em uma reserva florestal onde as trilhas mudam de lugar depois do pôr do sol."},
    {id:"reino-de-vidro",title:"Reino de Vidro",type:"movie",year:2023,genre:"Fantasia",duration:"2h 12min",rating:"10",poster:"img/reino-de-vidro.svg",featured:false,description:"Uma aprendiz de cartógrafa descobre um reino invisível refletido em superfícies de vidro e precisa impedir que os dois mundos se confundam."},
    {id:"linha-de-frente",title:"Linha de Frente",type:"movie",year:2022,genre:"Ação",duration:"1h 49min",rating:"14",poster:"img/linha-de-frente.svg",featured:false,description:"Depois de uma operação dar errado, uma equipe de resgate precisa atravessar uma cidade isolada para levar informações vitais até a central."},
    {id:"cartas-para-julho",title:"Cartas para Julho",type:"movie",year:2021,genre:"Drama",duration:"1h 44min",rating:"10",poster:"img/cartas-para-julho.svg",featured:false,description:"Uma caixa de cartas não enviadas aproxima duas pessoas que viveram a mesma história de maneiras completamente diferentes."},
    {id:"o-quarto-sinal",title:"O Quarto Sinal",type:"movie",year:2026,genre:"Mistério",duration:"1h 56min",rating:"14",poster:"img/o-quarto-sinal.svg",featured:false,description:"Uma estudante de rádio capta três sinais idênticos em noites consecutivas. Na quarta noite, a transmissão traz seu próprio nome."},
    {id:"arquivo-atlas",title:"Arquivo Atlas",type:"series",year:2026,genre:"Mistério",duration:"1 temporada",rating:"14",poster:"img/arquivo-atlas.svg",featured:true,description:"Uma equipe de arquivistas digitais investiga documentos que aparecem em sistemas públicos antes de serem criados. Cada arquivo abre um novo caso."},
    {id:"estacao-norte",title:"Estação Norte",type:"series",year:2025,genre:"Drama",duration:"2 temporadas",rating:"12",poster:"img/estacao-norte.svg",featured:true,description:"Em uma estação ferroviária no limite do país, passageiros e funcionários cruzam caminhos enquanto tentam descobrir o que significa recomeçar."},
    {id:"planeta-de-bolso",title:"Planeta de Bolso",type:"series",year:2024,genre:"Ficção científica",duration:"1 temporada",rating:"L",poster:"img/planeta-de-bolso.svg",featured:true,description:"Uma equipe de cientistas miniaturiza um ecossistema inteiro e descobre que as regras daquele pequeno mundo são muito mais estranhas do que imaginavam."},
    {id:"manual-do-caos",title:"Manual do Caos",type:"series",year:2025,genre:"Comédia",duration:"3 temporadas",rating:"12",poster:"img/manual-do-caos.svg",featured:true,description:"Quatro colegas dividem um apartamento e tentam seguir um manual de convivência que ninguém leu até o fim."},
    {id:"lendas-do-vazio",title:"Lendas do Vazio",type:"series",year:2023,genre:"Fantasia",duration:"2 temporadas",rating:"10",poster:"img/lendas-do-vazio.svg",featured:false,description:"Uma aprendiz de guardiã viaja por cidades que desapareceram dos mapas para reunir histórias capazes de manter o mundo unido."},
    {id:"plantao-da-meia-noite",title:"Plantão da Meia-Noite",type:"series",year:2024,genre:"Terror",duration:"1 temporada",rating:"16",poster:"img/plantao-da-meia-noite.svg",featured:false,description:"Durante o turno noturno de uma pequena rádio, ligações de ouvintes começam a descrever acontecimentos que ainda vão ocorrer."},
    {id:"rota-17",title:"Rota 17",type:"series",year:2022,genre:"Aventura",duration:"2 temporadas",rating:"12",poster:"img/rota-17.svg",featured:false,description:"Um ônibus que cruza o interior transporta passageiros com destinos muito diferentes, mas todos parecem estar fugindo de alguma coisa."}
  ];

  const $ = (sel, root=document) => root.querySelector(sel);
  const $$ = (sel, root=document) => [...root.querySelectorAll(sel)];
  const page = document.body.dataset.page || "";
  const listKey = "cineverse-watchlist-v1";

  function getSaved() {
    try {
      const parsed = JSON.parse(localStorage.getItem(listKey) || "[]");
      return Array.isArray(parsed) ? parsed : [];
    } catch { return []; }
  }
  function saveSaved(ids) {
    try { localStorage.setItem(listKey, JSON.stringify([...new Set(ids)])); }
    catch { showToast("Não foi possível salvar neste navegador."); }
  }
  function isSaved(id) { return getSaved().includes(id); }
  function showToast(message) {
    const toast = $("#toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove("show"), 2300);
  }
  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  }
  function cardTemplate(item) {
    const saved = isSaved(item.id);
    return `<article class="movie-card">
      <div class="card-actions"><button class="icon-btn ${saved ? "is-saved" : ""}" data-favorite="${item.id}" aria-label="${saved ? "Remover" : "Adicionar"} ${escapeHtml(item.title)} ${saved ? "da" : "à"} minha lista" aria-pressed="${saved}">${saved ? "♥" : "♡"}</button></div>
      <a class="poster-link" href="detalhes.html?id=${encodeURIComponent(item.id)}" aria-label="Ver detalhes de ${escapeHtml(item.title)}">
        <img src="${item.poster}" alt="Pôster ilustrado de ${escapeHtml(item.title)}" loading="lazy">
        <div class="poster-overlay"><span>＋ Ver detalhes</span></div>
      </a>
      <div class="card-topline"><h3 class="card-title" title="${escapeHtml(item.title)}">${escapeHtml(item.title)}</h3><span class="card-year">${item.year}</span></div>
      <div class="card-meta">${escapeHtml(item.genre)} <span>·</span> ${item.type === "series" ? "Série" : "Filme"}</div>
    </article>`;
  }
  function renderCards(target, items) {
    if (!target) return;
    target.innerHTML = items.map(cardTemplate).join("");
    target.querySelectorAll("[data-favorite]").forEach(button => button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      const id = button.dataset.favorite;
      let saved = getSaved();
      if (saved.includes(id)) {
        saved = saved.filter(x => x !== id);
        saveSaved(saved);
        showToast("Título removido da sua lista.");
      } else {
        saved.push(id);
        saveSaved(saved);
        showToast("Título adicionado à sua lista ♥");
      }
      refreshFavoriteButtons();
      if (page === "watchlist") renderWatchlist();
    }));
  }
  function refreshFavoriteButtons() {
    $$("[data-favorite]").forEach(button => {
      const saved = isSaved(button.dataset.favorite);
      button.classList.toggle("is-saved", saved);
      button.setAttribute("aria-pressed", String(saved));
      button.textContent = saved ? "♥" : "♡";
      button.setAttribute("aria-label", `${saved ? "Remover" : "Adicionar"} ${button.dataset.favorite} ${saved ? "da" : "à"} minha lista`);
    });
  }
  function renderHome() {
    renderCards($("#featuredMovies"), titles.filter(x => x.type === "movie" && x.featured).slice(0,5));
    renderCards($("#featuredSeries"), titles.filter(x => x.type === "series" && x.featured).slice(0,4));
  }
  function renderCatalog() {
    const grid = $("#catalogGrid");
    if (!grid) return;
    const type = page === "series" ? "series" : "movie";
    const searchInput = $("#catalogSearch");
    const genreSelect = $("#genreFilter");
    const sortSelect = $("#sortFilter");
    function apply() {
      const query = (searchInput?.value || "").trim().toLocaleLowerCase("pt-BR");
      const genre = genreSelect?.value || "all";
      const sort = sortSelect?.value || "featured";
      let items = titles.filter(item => item.type === type);
      if (query) items = items.filter(item => `${item.title} ${item.genre} ${item.year}`.toLocaleLowerCase("pt-BR").includes(query));
      if (genre !== "all") items = items.filter(item => item.genre === genre);
      if (sort === "title") items.sort((a,b) => a.title.localeCompare(b.title, "pt-BR"));
      if (sort === "year") items.sort((a,b) => b.year-a.year);
      if (sort === "featured") items.sort((a,b) => Number(b.featured)-Number(a.featured) || b.year-a.year);
      renderCards(grid, items);
      $("#resultCount").textContent = `${items.length} ${type === "series" ? (items.length === 1 ? "série encontrada" : "séries encontradas") : (items.length === 1 ? "filme encontrado" : "filmes encontrados")}`;
      $("#emptyState")?.classList.toggle("hidden", items.length !== 0);
      grid.classList.toggle("hidden", items.length === 0);
    }
    searchInput?.addEventListener("input", apply);
    genreSelect?.addEventListener("change", apply);
    sortSelect?.addEventListener("change", apply);
    $("#clearFilters")?.addEventListener("click", () => {
      if (searchInput) searchInput.value = "";
      if (genreSelect) genreSelect.value = "all";
      if (sortSelect) sortSelect.value = "featured";
      apply();
    });
    apply();
  }
  function renderDetails() {
    const container = $("#detailsContent");
    const id = new URLSearchParams(window.location.search).get("id");
    const item = titles.find(x => x.id === id);
    if (!item) {
      container.innerHTML = `<section class="page-main"><div class="empty-state"><span>⌕</span><h2>Título não encontrado</h2><p>Esse endereço não corresponde a um item do catálogo.</p><a class="btn btn-primary" href="filmes.html">Voltar ao catálogo</a></div></section>`;
      return;
    }
    document.title = `CineVerse | ${item.title}`;
    const saved = isSaved(item.id);
    container.innerHTML = `
      <section class="details-hero">
        <img class="details-backdrop" src="${item.poster}" alt="" aria-hidden="true">
        <div class="details-gradient"></div>
        <div class="details-layout">
          <img class="details-poster" src="${item.poster}" alt="Pôster ilustrado de ${escapeHtml(item.title)}">
          <div class="details-copy">
            <p class="eyebrow">${item.type === "series" ? "SÉRIE DO CATÁLOGO" : "FILME DO CATÁLOGO"}</p>
            <h1>${escapeHtml(item.title)}</h1>
            <div class="meta-line"><span class="tag">${item.rating}</span><span>${item.year}</span><span>•</span><span>${escapeHtml(item.genre)}</span><span>•</span><span>${escapeHtml(item.duration)}</span></div>
            <p class="description">${escapeHtml(item.description)}</p>
            <div class="hero-actions">
              <button class="btn btn-primary" id="catalogNotice"><span>▶</span> ${item.type === "series" ? "Ver episódios" : "Assistir agora"}</button>
              <button class="btn btn-glass" id="detailFavorite" aria-pressed="${saved}">${saved ? "♥ Na minha lista" : "♡ Minha lista"}</button>
            </div>
          </div>
        </div>
      </section>
      <section class="details-body">
        <h2>Sobre este título</h2><p>${escapeHtml(item.description)}</p>
        <div class="notice-panel"><span class="notice-icon">ⓘ</span><div><strong>Catálogo demonstrativo</strong><p>Esta versão apresenta informações fictícias e não reproduz vídeos. Nenhum link de filme foi inventado. O player poderá ser adicionado depois usando vídeos próprios, de domínio público ou fontes que autorizem a incorporação.</p></div></div>
      </section>`;
    $("#catalogNotice")?.addEventListener("click", () => showToast("O player será adicionado em uma próxima etapa."));
    $("#detailFavorite")?.addEventListener("click", () => {
      let savedIds = getSaved();
      if (savedIds.includes(item.id)) {
        savedIds = savedIds.filter(x => x !== item.id);
        showToast("Título removido da sua lista.");
      } else {
        savedIds.push(item.id);
        showToast("Título adicionado à sua lista ♥");
      }
      saveSaved(savedIds);
      const nowSaved = savedIds.includes(item.id);
      $("#detailFavorite").textContent = nowSaved ? "♥ Na minha lista" : "♡ Minha lista";
      $("#detailFavorite").setAttribute("aria-pressed", String(nowSaved));
    });
  }
  function renderWatchlist() {
    const grid = $("#watchlistGrid");
    if (!grid) return;
    const ids = getSaved();
    const items = ids.map(id => titles.find(item => item.id === id)).filter(Boolean);
    $("#resultCount").textContent = `${items.length} ${items.length === 1 ? "título salvo" : "títulos salvos"}`;
    renderCards(grid, items);
    grid.classList.toggle("hidden", items.length === 0);
    $("#watchlistEmpty")?.classList.toggle("hidden", items.length !== 0);
    $("#clearWatchlist")?.classList.toggle("hidden", items.length === 0);
  }
  function setupGlobalSearch() {
    const input = $("#globalSearch");
    if (!input) return;
    input.addEventListener("keydown", event => {
      if (event.key === "Enter") {
        const q = input.value.trim();
        const destination = page === "series" ? "series.html" : "filmes.html";
        window.location.href = `${destination}${q ? `?q=${encodeURIComponent(q)}` : ""}`;
      }
    });
    const query = new URLSearchParams(window.location.search).get("q");
    if (query && $("#catalogSearch")) {
      $("#catalogSearch").value = query;
      $("#catalogSearch").dispatchEvent(new Event("input", {bubbles:true}));
    }
  }
  function setupMobileMenu() {
    const button = $("#menuToggle");
    const nav = $(".main-nav");
    if (!button || !nav) return;
    button.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      button.setAttribute("aria-expanded", String(open));
      button.setAttribute("aria-label", open ? "Fechar menu" : "Abrir menu");
      button.textContent = open ? "×" : "☰";
    });
  }

  setupMobileMenu();
  setupGlobalSearch();
  if (page === "home") renderHome();
  if (page === "movies" || page === "series") renderCatalog();
  if (page === "details") renderDetails();
  if (page === "watchlist") {
    renderWatchlist();
    $("#clearWatchlist")?.addEventListener("click", () => {
      saveSaved([]);
      renderWatchlist();
      showToast("Sua lista foi limpa.");
    });
  }
})();